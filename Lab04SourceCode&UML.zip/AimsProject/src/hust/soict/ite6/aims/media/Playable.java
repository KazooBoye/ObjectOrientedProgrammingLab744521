package hust.soict.ite6.aims.media;

public interface Playable {
	public void play();
}
